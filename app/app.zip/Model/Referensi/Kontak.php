<?php

namespace App\Model\Referensi;

use Illuminate\Database\Eloquent\Model;

class Kontak extends Model
{
    //
}
